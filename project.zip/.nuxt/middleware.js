const middleware = {}

middleware['authMiddleware'] = require('../middleware/authMiddleware.js')
middleware['authMiddleware'] = middleware['authMiddleware'].default || middleware['authMiddleware']

export default middleware
