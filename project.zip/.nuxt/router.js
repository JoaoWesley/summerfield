import Vue from 'vue'
import Router from 'vue-router'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _8391f1c2 = () => interopDefault(import('../pages/feedback/index.vue' /* webpackChunkName: "pages/feedback/index" */))
const _973bae5c = () => interopDefault(import('../pages/lesson/index.vue' /* webpackChunkName: "pages/lesson/index" */))
const _41624af2 = () => interopDefault(import('../pages/review/index.vue' /* webpackChunkName: "pages/review/index" */))
const _69768abd = () => interopDefault(import('../pages/lesson/_id/index.vue' /* webpackChunkName: "pages/lesson/_id/index" */))
const _2914bf98 = () => interopDefault(import('../pages/lesson/_id/_topic/index.vue' /* webpackChunkName: "pages/lesson/_id/_topic/index" */))
const _cf22bd50 = () => interopDefault(import('../pages/lesson/_id/_topic/_topicId/index.vue' /* webpackChunkName: "pages/lesson/_id/_topic/_topicId/index" */))
const _1d46a8cb = () => interopDefault(import('../pages/index.vue' /* webpackChunkName: "pages/index" */))

// TODO: remove in Nuxt 3
const emptyFn = () => {}
const originalPush = Router.prototype.push
Router.prototype.push = function push (location, onComplete = emptyFn, onAbort) {
  return originalPush.call(this, location, onComplete, onAbort)
}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: decodeURI('/'),
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/feedback",
    component: _8391f1c2,
    name: "feedback"
  }, {
    path: "/lesson",
    component: _973bae5c,
    name: "lesson"
  }, {
    path: "/review",
    component: _41624af2,
    name: "review"
  }, {
    path: "/lesson/:id",
    component: _69768abd,
    name: "lesson-id"
  }, {
    path: "/lesson/:id/:topic",
    component: _2914bf98,
    name: "lesson-id-topic"
  }, {
    path: "/lesson/:id/:topic/:topicId",
    component: _cf22bd50,
    name: "lesson-id-topic-topicId"
  }, {
    path: "/",
    component: _1d46a8cb,
    name: "index"
  }],

  fallback: false
}

export function createRouter () {
  return new Router(routerOptions)
}
