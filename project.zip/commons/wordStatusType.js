const wordStatusType = {
  NEW: 'NEW',
  LEARNING: 'LEARNING',
  KNOWN: 'KNOWN',
}

export default wordStatusType
