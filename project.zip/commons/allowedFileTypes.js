const allowedFileTypes = [
  'application/epub+zip', // EPUB
  'application/pdf', // PDF
  'application/vnd.openxmlformats-officedocument.wordprocessingml.document', // DOCX
]

export default allowedFileTypes
