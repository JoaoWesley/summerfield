const textTokenSpacerType = {
  BR: '<br/><br/>',
}

export default textTokenSpacerType
